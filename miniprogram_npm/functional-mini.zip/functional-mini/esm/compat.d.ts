export * from './3rd-party/compat.js';
import compat from './3rd-party/compat.js';
export default compat;
