import { setLogSwitch } from './utils.js';
export { setLogSwitch };
