export declare enum ETargetPlatform {
    alipay = "alipay",
    wechat = "wechat"
}
export declare enum EElementType {
    page = "page",
    component = "component"
}
