export { act } from 'preact/test-utils';
