import * as preact from 'preact';
import * as preactHooks from 'preact/hooks';

export { render as serverRender } from 'preact-render-to-string';

export { preact, preactHooks };
