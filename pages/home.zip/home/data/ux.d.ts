declare const ux: {
    name: string;
    icon: string;
    childArr: {
        name: string;
        label: string;
    }[];
};
export default ux;
