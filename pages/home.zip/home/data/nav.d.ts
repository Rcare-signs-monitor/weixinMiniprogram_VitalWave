declare const nav: {
    name: string;
    icon: string;
    childArr: {
        name: string;
        label: string;
    }[];
};
export default nav;
