const display = {
    name: '健康档案',
    icon: 'image',
    childArr: [
        {
            name: 'document',
            label: '查看健康档案',
        },
    ],
};
export default display;
