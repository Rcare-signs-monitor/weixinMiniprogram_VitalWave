const ux = {
    name: '医疗服务',
    icon: 'chat',
    childArr: [
        {
            name: 'DoctorService',
            label: '联系医生',
        },
    ],
};
export default ux;
