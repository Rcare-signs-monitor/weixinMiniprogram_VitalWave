const nav = {
    name: '定位',
    icon: 'view-module',
    childArr: [
        {
          name: 'Locate',
          label: '定位',
      },
    ],
};
export default nav;
