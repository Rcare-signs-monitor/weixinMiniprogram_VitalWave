import list from './data/index';
const app = getApp();
function isUpperCase(str) {
  return str === str.toUpperCase();
}
Page({
    data: {
        list,
    },
    onLoad(options) {
        const { path, q } = options;
        // console.log(path);
        if (q) {
            const str = this.getQueryByUrl(decodeURIComponent(q));
            console.log(str, str.page);
            wx.navigateTo({
                url: `/pages/${str.page}/${str.page}`,
            });
        }
    
        if (app.globalData.userInfo != null)
        {
          console.log(app.globalData.userInfo)
          this.setData({
            is_login: true,
          });
        }
    },
    clickHandle(e) 
    // e是一个网络请求
    {
      if(app.globalData.userInfo == null)
      {
        wx.showToast({
          title: '请先登录',  // 提示的内容
          icon: 'none',   // 提示图标，可选值有 'success', 'loading'，默认是 'success'
          duration: 2000      // 提示的延迟时间，单位毫秒，默认是 1500
        });
      }
      else
      {
        let { name, path = '' } = e.detail.item;
        // console.log(e.detail.item)
        if (!path) {
          if(!isUpperCase(name))
          {
            name = name.replace(/^[A-Z]/, (match) => `${match}`.toLocaleLowerCase());
            name = name.replace(/[A-Z]/g, (match) => {
                return `-${match.toLowerCase()}`;
            });
            path = `/pages/${name}/${name}`;
            // console.log(path)
          }
          else
          {
            path = `/pages/${name}/${name}`;
          }
            
        }
        wx.navigateTo({
            url: path,
            fail: () => {
                wx.navigateTo({
                    url: '/pages/home/navigateFail/navigateFail',
                });
            },
        });
      }
    },
    onShareAppMessage() {
        return {
            title: 'TDesign UI',
            path: '/pages/home/home',
        };
    },
    getQueryByUrl(url) {
        const data = {};
        const queryArr = `${url}`.match(/([^=&#?]+)=[^&#]+/g) || [];
        if (queryArr.length) {
            queryArr.forEach((para) => {
                const d = para.split('=');
                const val = decodeURIComponent(d[1]);
                if (data[d[0]] !== undefined) {
                    data[d[0]] += `,${val}`;
                }
                else {
                    data[d[0]] = val;
                }
            });
        }
        return data;
    },
});
