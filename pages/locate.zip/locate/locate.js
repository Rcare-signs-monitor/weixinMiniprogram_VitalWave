import * as echarts from '../../ec-canvas/echarts';


const app = getApp();
const db = wx.cloud.database();
const Medical = db.collection('Medical_Record')

let timer;//定时刷新，页面退出后关闭定时器
let records;
Medical.where({
  type: 'HR',
})
.get({
  success: function(res) {
    console.log(res.data)
    records = res.data
  }
})

var ROOT_PATH = 'https://echarts.apache.org/examples';
const dataURL = ROOT_PATH + '/data/asset/data/fake-nebula.bin';
var rawData;
wx.request({
        url: dataURL,
        responseType: 'arraybuffer', // 指定响应的数据类型为二进制数组
        success: function (res) {
          // 在这里处理获取到的二进制数据
            var rawData1 = new Float32Array(res.data);
            rawData = handle_rawdata(rawData1).slice(0, 10000)
            
            console.log(rawData)
        },
        fail: function (error) {
          console.error('Request failed:', error);
        }
      });
function handle_rawdata(rawData){
  var result = [];
  for (var i = 0; i < rawData.length; i += 2) 
  {
  // 取两个元素组成一个子数组
  var subArray = [rawData[i], rawData[i + 1]];
  // 将子数组添加到结果数组中
  result.push(subArray);
  }
  return result;
}
// //曲线设置
// function setOption(chart, rawData) {
//   const option = {
//     title: {
//       left: 'center',
//       text:
//         echarts.format.addCommas(Math.round(rawData.length / 2)) + ' Points',
//       subtext: 'Fake data'
//     },
//     tooltip: {},
//     toolbox: {
//       right: 20,
//       feature: {
//         dataZoom: {}
//       }
//     },
//     grid: {
//       right: 70,
//       bottom: 70
//     },
//     xAxis: [{}],
//     yAxis: [{}],
//     dataZoom: [
//       {
//         type: 'inside'
//       },
//       {
//         type: 'slider',
//         showDataShadow: false,
//         handleIcon:
//           'path://M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
//         handleSize: '80%'
//       },
//       {
//         type: 'inside',
//         orient: 'vertical'
//       },
//       {
//         type: 'slider',
//         orient: 'vertical',
//         showDataShadow: false,
//         handleIcon:
//           'path://M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
//         handleSize: '80%'
//       }
//     ],
//     animation: false,
//     series: [
//       {
//         type: 'scatter',
//         data: rawData,
//         dimensions: ['x', 'y'],
//         symbolSize: 3,
//         itemStyle: {
//           opacity: 0.4
//         },
//         blendMode: 'source-over',
//         large: true,
//         largeThreshold: 500
//       }
//     ]
//   };
//   chart.setOption(option)
// }

// Page({
//   data: {
//     ec: {
//       lazyLoad: true
//     },
//   },
//   /**
//    * 生命周期函数--监听页面加载
//    */
//   onLoad(options) {
//     //初始化曲线
//     var that = this;
//     this.init_echart().then(() => {
//       // wx.request({
//       //   url: dataURL,
//       //   responseType: 'arraybuffer', // 指定响应的数据类型为二进制数组
//       //   success: function (res) {
//       //     // 在这里处理获取到的二进制数据
//       //     var rawData = new Float32Array(res.data);
//       //     // that.myChart.hideLoading();
//       //     setOption(that.myChart, res.data);
//       //   },
//       //   fail: function (error) {
//       //     console.error('Request failed:', error);
//       //   }
//       // });
//       wx.getFileSystemManager().readFile({
//         filePath: 'pages/locate/fake-nebula.bin',
//         encoding: 'binary', // 指定编码方式为二进制
//         success: function (res) {
//           // 在这里处理读取到的二进制数据
//           var rawData = new Float32Array(res.data);
//           var binaryData = res.data;
//           setOption(that.myChart, rawData);
          
//         },
//         fail: function (error) {
//           console.error('Read file failed:', error);
//         }
//       });
      
//     })
    
//     //每隔60s刷新一次
//     // timer = setInterval(() => {
//     //   // this.myChart.showLoading();
//     //   // xhr.onload = function (e) {
//     //   //   myChart.hideLoading();
//     //   //   var rawData = new Float32Array(this.response);
//     //   //   setOption(this.myChart, rawData)
//     //   // };
//     //   // xhr.send();
      
//     // }, 2100)
//   },

//   /**
//    * 生命周期函数--监听页面初次渲染完成
//    */
//   onReady() {

//   },

//   /**
//    * 生命周期函数--监听页面显示
//    */
//   onShow() {

//   },

//   /**
//    * 生命周期函数--监听页面隐藏
//    */
//   onHide() {

//   },

//   /**
//    * 生命周期函数--监听页面卸载
//    */
//   onUnload() {
//     clearInterval(timer)//注销定时器
//   },

//   /**
//    * 页面相关事件处理函数--监听用户下拉动作
//    */
//   onPullDownRefresh() {

//   },

//   /**
//    * 页面上拉触底事件的处理函数
//    */
//   onReachBottom() {

//   },

//   // 初始化图表，放在 onLoad() 中(主要是为了得到 myChart )
//   init_echart() {
//     return new Promise((resolve) => {
//       this.Component = this.selectComponent('#mychart');
//       this.Component.init((canvas, width, height) => {
//         const chart = echarts.init(canvas, null, {
//           width: width,
//           height: height
//         });
//         this.myChart = chart; // 将初始化的图表传递到 this.myChart 中
//         resolve(chart); // 解决 Promise，传递图表对象
//       });
//     });
//   },
  
//   // 给图表加上数据
//   getOption: function () {

//     // for (let i = 0; i < records.length; i++) {
//     //   if (!xAxisArray.includes(i))
//     //   {
//     //     xAxisArray.push(i);
//     //     yAxisArray.push(records[i].value);
//     //   }
//     //   console.log(records[i].value);
//     // }    
//     // if (xAxisArray.length >= 30) {
//     //   xAxisArray.shift(); //如果数据超过了需要解析的最大值，则清除前面的数据，以保留最新的数值
//     //   yAxisArray.shift();
//     // }

//     //利用 myChart 直接绘制曲线
//     setOption(this.myChart, xAxisArray, yAxisArray)
//   },
// });
function initChart(canvas, width, height, dpr) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr // 像素比
  });
  canvas.setChart(chart);

  var option = {
    title: {
      left: 'center',
      text:
        echarts.format.addCommas(Math.round(rawData.length)) + ' Points',
      subtext: 'Fake data'
    },
    tooltip: {},
    toolbox: {
      right: 20,
      feature: {
        dataZoom: {}
      }
    },
    grid: {
      right: 70,
      bottom: 70
    },
    xAxis: [{}],
    yAxis: [{}],
    dataZoom: [
      {
        type: 'inside'
      },
      {
        type: 'slider',
        showDataShadow: false,
        handleIcon:
          'path://M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
        handleSize: '80%'
      },
      {
        type: 'inside',
        orient: 'vertical'
      },
      {
        type: 'slider',
        orient: 'vertical',
        showDataShadow: false,
        handleIcon:
          'path://M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
        handleSize: '80%'
      }
    ],
    animation: false,
    series: [
      {
        type: 'scatter',
        data: rawData,
        symbolSize: 3,
        itemStyle: {
          opacity: 0.4
        },
        
        large: true,
        largeThreshold: 500
      }
    ]
  };
  chart.setOption(option);
  return chart;
}

Page({
  data: {
    ec: {
      onInit: initChart
    }
  }
});